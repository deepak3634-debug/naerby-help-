import 'package:flutter/foundation.dart';
import '../config/api_config.dart';
import '../models/provider_model.dart';
import '../services/api_service.dart';
import '../services/location_service.dart';

/// Drives the "home" / nearby-providers screen: fetches the user's current
/// location, queries the backend for nearby service providers, and exposes
/// simple filtering by service type.
class NearbyProvider extends ChangeNotifier {
  final ApiService _apiService;
  final LocationService _locationService;

  NearbyProvider({ApiService? apiService, LocationService? locationService})
      : _apiService = apiService ?? ApiService(),
        _locationService = locationService ?? LocationService();

  bool _isLoading = false;
  String? _errorMessage;
  double? _currentLat;
  double? _currentLng;
  List<ProviderModel> _providers = [];
  String? _selectedServiceFilter;

  bool get isLoading => _isLoading;
  String? get errorMessage => _errorMessage;
  double? get currentLat => _currentLat;
  double? get currentLng => _currentLng;
  String? get selectedServiceFilter => _selectedServiceFilter;

  List<ProviderModel> get providers {
    if (_selectedServiceFilter == null) return _providers;
    return _providers
        .where((p) => p.services.contains(_selectedServiceFilter))
        .toList();
  }

  Future<void> loadNearbyProviders({double radiusKm = 10}) async {
    _isLoading = true;
    _errorMessage = null;
    notifyListeners();

    try {
      final position = await _locationService.getCurrentPosition();
      _currentLat = position.latitude;
      _currentLng = position.longitude;

      final data = await _apiService.get(
        ApiConfig.nearbyProviders,
        query: {
          'lat': _currentLat,
          'lng': _currentLng,
          'radiusKm': radiusKm,
        },
      );

      final list = (data is List) ? data : (data['providers'] as List? ?? []);
      _providers = list
          .map((e) => ProviderModel.fromJson(e as Map<String, dynamic>))
          .toList();
    } catch (e) {
      _errorMessage = e.toString().replaceFirst('Exception: ', '');
    } finally {
      _isLoading = false;
      notifyListeners();
    }
  }

  void setServiceFilter(String? serviceType) {
    _selectedServiceFilter = serviceType;
    notifyListeners();
  }

  Future<void> refresh() => loadNearbyProviders();
}
