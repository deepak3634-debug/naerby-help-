import 'dart:convert';
import 'package:flutter_secure_storage/flutter_secure_storage.dart';
import 'package:http/http.dart' as http;
import '../config/api_config.dart';
import '../models/user_model.dart';

/// Handles the phone + OTP login flow and secure storage of JWT tokens.
/// Kept separate from [ApiService] to avoid a circular dependency
/// (ApiService needs a token getter; AuthService needs to hit unauthenticated
/// endpoints like send-otp/verify-otp).
class AuthService {
  static final AuthService _instance = AuthService._internal();
  factory AuthService() => _instance;
  AuthService._internal();

  final _storage = const FlutterSecureStorage();
  static const _kAccessToken = 'access_token';
  static const _kRefreshToken = 'refresh_token';

  Future<String?> getAccessToken() => _storage.read(key: _kAccessToken);
  Future<String?> getRefreshToken() => _storage.read(key: _kRefreshToken);

  Future<void> _saveTokens({required String access, required String refresh}) async {
    await _storage.write(key: _kAccessToken, value: access);
    await _storage.write(key: _kRefreshToken, value: refresh);
  }

  Future<void> clearTokens() async {
    await _storage.delete(key: _kAccessToken);
    await _storage.delete(key: _kRefreshToken);
  }

  Future<bool> isLoggedIn() async => (await getAccessToken()) != null;

  /// Step 1: request an OTP be sent to [phone].
  Future<void> sendOtp(String phone) async {
    final res = await http.post(
      Uri.parse('${ApiConfig.baseUrl}${ApiConfig.sendOtp}'),
      headers: {'Content-Type': 'application/json'},
      body: jsonEncode({'phone': phone}),
    );
    if (res.statusCode < 200 || res.statusCode >= 300) {
      throw Exception(_extractMessage(res.body) ?? 'Failed to send OTP');
    }
  }

  /// Step 2: verify the OTP code. Returns the logged-in user on success
  /// and persists the JWT access/refresh tokens.
  Future<UserModel> verifyOtp({required String phone, required String otp}) async {
    final res = await http.post(
      Uri.parse('${ApiConfig.baseUrl}${ApiConfig.verifyOtp}'),
      headers: {'Content-Type': 'application/json'},
      body: jsonEncode({'phone': phone, 'otp': otp}),
    );

    if (res.statusCode < 200 || res.statusCode >= 300) {
      throw Exception(_extractMessage(res.body) ?? 'Invalid OTP');
    }

    final data = jsonDecode(res.body);
    await _saveTokens(
      access: data['accessToken'],
      refresh: data['refreshToken'],
    );
    return UserModel.fromJson(data['user']);
  }

  /// Refresh the access token using the stored refresh token.
  /// Returns true if refreshed successfully.
  Future<bool> refreshAccessToken() async {
    final refresh = await getRefreshToken();
    if (refresh == null) return false;

    final res = await http.post(
      Uri.parse('${ApiConfig.baseUrl}${ApiConfig.refreshToken}'),
      headers: {'Content-Type': 'application/json'},
      body: jsonEncode({'refreshToken': refresh}),
    );

    if (res.statusCode < 200 || res.statusCode >= 300) {
      await clearTokens();
      return false;
    }

    final data = jsonDecode(res.body);
    await _saveTokens(access: data['accessToken'], refresh: data['refreshToken']);
    return true;
  }

  Future<UserModel?> fetchCurrentUser() async {
    final token = await getAccessToken();
    if (token == null) return null;

    final res = await http.get(
      Uri.parse('${ApiConfig.baseUrl}${ApiConfig.me}'),
      headers: {'Authorization': 'Bearer $token'},
    );
    if (res.statusCode != 200) return null;
    return UserModel.fromJson(jsonDecode(res.body));
  }

  Future<void> logout() async {
    await clearTokens();
  }

  String? _extractMessage(String body) {
    try {
      final decoded = jsonDecode(body);
      return decoded is Map ? decoded['message']?.toString() : null;
    } catch (_) {
      return null;
    }
  }
}
