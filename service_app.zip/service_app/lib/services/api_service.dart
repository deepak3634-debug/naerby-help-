import 'dart:convert';
import 'package:http/http.dart' as http;
import '../config/api_config.dart';
import 'auth_service.dart';

class ApiException implements Exception {
  final String message;
  final int? statusCode;
  ApiException(this.message, {this.statusCode});

  @override
  String toString() => 'ApiException($statusCode): $message';
}

/// Thin wrapper around [http] that injects base URL, JSON headers,
/// the current auth token, and normalizes error handling.
class ApiService {
  final AuthService _authService;
  final http.Client _client;

  ApiService({AuthService? authService, http.Client? client})
      : _authService = authService ?? AuthService(),
        _client = client ?? http.Client();

  Uri _uri(String path, [Map<String, dynamic>? query]) {
    final url = '${ApiConfig.baseUrl}$path';
    return Uri.parse(url).replace(
      queryParameters: query?.map((k, v) => MapEntry(k, '$v')),
    );
  }

  Future<Map<String, String>> _headers({bool auth = true}) async {
    final headers = {'Content-Type': 'application/json'};
    if (auth) {
      final token = await _authService.getAccessToken();
      if (token != null) headers['Authorization'] = 'Bearer $token';
    }
    return headers;
  }

  Future<dynamic> get(String path, {Map<String, dynamic>? query, bool auth = true}) async {
    final res = await _client
        .get(_uri(path, query), headers: await _headers(auth: auth))
        .timeout(ApiConfig.requestTimeout);
    return _handle(res);
  }

  Future<dynamic> post(String path, {Object? body, bool auth = true}) async {
    final res = await _client
        .post(_uri(path), headers: await _headers(auth: auth), body: jsonEncode(body))
        .timeout(ApiConfig.requestTimeout);
    return _handle(res);
  }

  Future<dynamic> put(String path, {Object? body, bool auth = true}) async {
    final res = await _client
        .put(_uri(path), headers: await _headers(auth: auth), body: jsonEncode(body))
        .timeout(ApiConfig.requestTimeout);
    return _handle(res);
  }

  Future<dynamic> delete(String path, {bool auth = true}) async {
    final res = await _client
        .delete(_uri(path), headers: await _headers(auth: auth))
        .timeout(ApiConfig.requestTimeout);
    return _handle(res);
  }

  dynamic _handle(http.Response res) {
    final code = res.statusCode;
    dynamic decoded;
    try {
      decoded = res.body.isNotEmpty ? jsonDecode(res.body) : null;
    } catch (_) {
      decoded = res.body;
    }

    if (code >= 200 && code < 300) {
      return decoded;
    }

    final message = (decoded is Map && decoded['message'] != null)
        ? decoded['message'].toString()
        : 'Request failed with status $code';
    throw ApiException(message, statusCode: code);
  }
}
