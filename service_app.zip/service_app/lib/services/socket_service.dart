import 'package:socket_io_client/socket_io_client.dart' as io;
import '../config/api_config.dart';
import 'auth_service.dart';

/// Thin wrapper around socket_io_client so the rest of the app never
/// touches the socket library directly. Handles auth-token injection,
/// (re)connection, and a simple typed event-listener API.
class SocketService {
  static final SocketService _instance = SocketService._internal();
  factory SocketService() => _instance;
  SocketService._internal();

  io.Socket? _socket;
  bool get isConnected => _socket?.connected ?? false;

  Future<void> connect() async {
    if (_socket != null && _socket!.connected) return;

    final token = await AuthService().getAccessToken();

    _socket = io.io(
      ApiConfig.socketUrl,
      io.OptionBuilder()
          .setTransports(['websocket'])
          .disableAutoConnect()
          .setAuth({'token': token})
          .setReconnectionAttempts(5)
          .setReconnectionDelay(2000)
          .build(),
    );

    _socket!.connect();

    _socket!.onConnect((_) => print('[socket] connected'));
    _socket!.onDisconnect((_) => print('[socket] disconnected'));
    _socket!.onConnectError((err) => print('[socket] connect_error: $err'));
    _socket!.onError((err) => print('[socket] error: $err'));
  }

  /// Listen for a named event, e.g. 'request:status_update', 'provider:location'.
  void on(String event, void Function(dynamic data) handler) {
    _socket?.on(event, handler);
  }

  void off(String event) {
    _socket?.off(event);
  }

  void emit(String event, dynamic data) {
    _socket?.emit(event, data);
  }

  /// Join a room specific to a service request so both the user and the
  /// provider get realtime status/location updates for that booking.
  void joinRequestRoom(String requestId) {
    emit('request:join', {'requestId': requestId});
  }

  void leaveRequestRoom(String requestId) {
    emit('request:leave', {'requestId': requestId});
  }

  void disconnect() {
    _socket?.disconnect();
    _socket?.dispose();
    _socket = null;
  }
}
