enum ServiceRequestStatus {
  pending,
  accepted,
  onTheWay,
  inProgress,
  completed,
  cancelled;

  static ServiceRequestStatus fromString(String? value) {
    switch (value) {
      case 'accepted':
        return ServiceRequestStatus.accepted;
      case 'on_the_way':
        return ServiceRequestStatus.onTheWay;
      case 'in_progress':
        return ServiceRequestStatus.inProgress;
      case 'completed':
        return ServiceRequestStatus.completed;
      case 'cancelled':
        return ServiceRequestStatus.cancelled;
      default:
        return ServiceRequestStatus.pending;
    }
  }

  String get label {
    switch (this) {
      case ServiceRequestStatus.pending:
        return 'Pending';
      case ServiceRequestStatus.accepted:
        return 'Accepted';
      case ServiceRequestStatus.onTheWay:
        return 'On the way';
      case ServiceRequestStatus.inProgress:
        return 'In progress';
      case ServiceRequestStatus.completed:
        return 'Completed';
      case ServiceRequestStatus.cancelled:
        return 'Cancelled';
    }
  }
}

class ServiceRequestModel {
  final String id;
  final String userId;
  final String providerId;
  final String serviceType;
  final String? notes;
  final ServiceRequestStatus status;
  final double latitude;
  final double longitude;
  final String address;
  final double? estimatedPrice;
  final DateTime createdAt;
  final DateTime? scheduledFor;

  ServiceRequestModel({
    required this.id,
    required this.userId,
    required this.providerId,
    required this.serviceType,
    this.notes,
    required this.status,
    required this.latitude,
    required this.longitude,
    required this.address,
    this.estimatedPrice,
    required this.createdAt,
    this.scheduledFor,
  });

  factory ServiceRequestModel.fromJson(Map<String, dynamic> json) {
    return ServiceRequestModel(
      id: json['_id'] ?? json['id'] ?? '',
      userId: json['userId'] ?? '',
      providerId: json['providerId'] ?? '',
      serviceType: json['serviceType'] ?? '',
      notes: json['notes'],
      status: ServiceRequestStatus.fromString(json['status']),
      latitude: (json['latitude'] as num?)?.toDouble() ?? 0,
      longitude: (json['longitude'] as num?)?.toDouble() ?? 0,
      address: json['address'] ?? '',
      estimatedPrice: (json['estimatedPrice'] as num?)?.toDouble(),
      createdAt: json['createdAt'] != null
          ? DateTime.tryParse(json['createdAt']) ?? DateTime.now()
          : DateTime.now(),
      scheduledFor: json['scheduledFor'] != null
          ? DateTime.tryParse(json['scheduledFor'])
          : null,
    );
  }

  Map<String, dynamic> toCreateJson() {
    return {
      'providerId': providerId,
      'serviceType': serviceType,
      'notes': notes,
      'latitude': latitude,
      'longitude': longitude,
      'address': address,
      if (scheduledFor != null) 'scheduledFor': scheduledFor!.toIso8601String(),
    };
  }
}
