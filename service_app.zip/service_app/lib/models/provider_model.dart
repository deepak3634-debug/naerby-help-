class ProviderModel {
  final String id;
  final String name;
  final String? avatarUrl;
  final List<String> services; // e.g. ["Plumbing", "Electrical"]
  final double rating;
  final int totalReviews;
  final double latitude;
  final double longitude;
  final double? distanceKm; // populated by nearby search
  final bool isOnline;
  final bool isVerified;
  final double pricePerHour;

  ProviderModel({
    required this.id,
    required this.name,
    this.avatarUrl,
    required this.services,
    required this.rating,
    required this.totalReviews,
    required this.latitude,
    required this.longitude,
    this.distanceKm,
    required this.isOnline,
    required this.isVerified,
    required this.pricePerHour,
  });

  factory ProviderModel.fromJson(Map<String, dynamic> json) {
    final loc = json['location'];
    double lat = 0, lng = 0;
    if (loc != null && loc['coordinates'] is List) {
      // GeoJSON: [lng, lat]
      lng = (loc['coordinates'][0] as num).toDouble();
      lat = (loc['coordinates'][1] as num).toDouble();
    } else {
      lat = (json['latitude'] as num?)?.toDouble() ?? 0;
      lng = (json['longitude'] as num?)?.toDouble() ?? 0;
    }

    return ProviderModel(
      id: json['_id'] ?? json['id'] ?? '',
      name: json['name'] ?? '',
      avatarUrl: json['avatarUrl'],
      services: (json['services'] as List?)?.map((e) => e.toString()).toList() ?? [],
      rating: (json['rating'] as num?)?.toDouble() ?? 0,
      totalReviews: json['totalReviews'] ?? 0,
      latitude: lat,
      longitude: lng,
      distanceKm: (json['distanceKm'] as num?)?.toDouble(),
      isOnline: json['isOnline'] ?? false,
      isVerified: json['isVerified'] ?? false,
      pricePerHour: (json['pricePerHour'] as num?)?.toDouble() ?? 0,
    );
  }

  Map<String, dynamic> toJson() {
    return {
      'id': id,
      'name': name,
      'avatarUrl': avatarUrl,
      'services': services,
      'rating': rating,
      'totalReviews': totalReviews,
      'latitude': latitude,
      'longitude': longitude,
      'isOnline': isOnline,
      'isVerified': isVerified,
      'pricePerHour': pricePerHour,
    };
  }
}
