/// Central place for backend endpoints & environment config.
/// Swap [Environment.current] to point the app at local / staging / prod.
enum Environment { local, staging, production }

class ApiConfig {
  ApiConfig._();

  static const Environment current = Environment.local;

  static String get baseUrl {
    switch (current) {
      case Environment.local:
        // Use 10.0.2.2 for Android emulator -> host machine localhost
        return 'http://10.0.2.2:5000/api';
      case Environment.staging:
        return 'https://staging-api.yourapp.com/api';
      case Environment.production:
        return 'https://api.yourapp.com/api';
    }
  }

  static String get socketUrl {
    switch (current) {
      case Environment.local:
        return 'http://10.0.2.2:5000';
      case Environment.staging:
        return 'https://staging-api.yourapp.com';
      case Environment.production:
        return 'https://api.yourapp.com';
    }
  }

  // ---- Auth ----
  static const String sendOtp = '/auth/send-otp';
  static const String verifyOtp = '/auth/verify-otp';
  static const String refreshToken = '/auth/refresh';
  static const String me = '/auth/me';

  // ---- Providers / nearby ----
  static const String nearbyProviders = '/providers/nearby';
  static const String providerDetail = '/providers'; // + /:id

  // ---- Service requests / bookings ----
  static const String serviceRequests = '/service-requests';

  // ---- Networking ----
  static const Duration requestTimeout = Duration(seconds: 15);
}
