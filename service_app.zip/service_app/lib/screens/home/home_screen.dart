import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../../providers/auth_provider.dart';
import '../../providers/nearby_provider.dart';
import '../../widgets/loading_indicator.dart';
import '../../widgets/provider_card.dart';
import '../provider_profile/provider_profile_screen.dart';

class HomeScreen extends StatefulWidget {
  const HomeScreen({super.key});

  @override
  State<HomeScreen> createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen> {
  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance.addPostFrameCallback((_) {
      context.read<NearbyProvider>().loadNearbyProviders();
    });
  }

  @override
  Widget build(BuildContext context) {
    final nearby = context.watch<NearbyProvider>();
    final auth = context.watch<AuthProvider>();

    return Scaffold(
      appBar: AppBar(
        title: Text('Hi, ${auth.user?.name.split(' ').first ?? 'there'} 👋'),
        actions: [
          IconButton(
            icon: const Icon(Icons.logout),
            onPressed: () => context.read<AuthProvider>().logout(),
          ),
        ],
      ),
      body: RefreshIndicator(
        onRefresh: () => nearby.refresh(),
        child: _buildBody(nearby),
      ),
    );
  }

  Widget _buildBody(NearbyProvider nearby) {
    if (nearby.isLoading && nearby.providers.isEmpty) {
      return const LoadingIndicator(message: 'Finding nearby providers...');
    }

    if (nearby.errorMessage != null && nearby.providers.isEmpty) {
      return ErrorRetryView(
        message: nearby.errorMessage!,
        onRetry: () => nearby.loadNearbyProviders(),
      );
    }

    if (nearby.providers.isEmpty) {
      return const Center(child: Text('No providers found nearby.'));
    }

    return ListView.builder(
      physics: const AlwaysScrollableScrollPhysics(),
      itemCount: nearby.providers.length,
      itemBuilder: (context, index) {
        final provider = nearby.providers[index];
        return ProviderCard(
          provider: provider,
          onTap: () {
            Navigator.of(context).push(
              MaterialPageRoute(
                builder: (_) => ProviderProfileScreen(provider: provider),
              ),
            );
          },
        );
      },
    );
  }
}
