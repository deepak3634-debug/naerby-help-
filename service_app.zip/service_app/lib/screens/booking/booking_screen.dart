import 'package:flutter/material.dart';
import '../../config/api_config.dart';
import '../../models/provider_model.dart';
import '../../models/service_request_model.dart';
import '../../services/api_service.dart';
import '../../services/location_service.dart';
import '../../widgets/custom_button.dart';
import '../../widgets/custom_text_field.dart';

class BookingScreen extends StatefulWidget {
  final ProviderModel provider;
  const BookingScreen({super.key, required this.provider});

  @override
  State<BookingScreen> createState() => _BookingScreenState();
}

class _BookingScreenState extends State<BookingScreen> {
  final _formKey = GlobalKey<FormState>();
  final _addressController = TextEditingController();
  final _notesController = TextEditingController();
  final _apiService = ApiService();
  final _locationService = LocationService();

  String? _selectedService;
  bool _isSubmitting = false;

  @override
  void initState() {
    super.initState();
    _selectedService = widget.provider.services.isNotEmpty ? widget.provider.services.first : null;
  }

  @override
  void dispose() {
    _addressController.dispose();
    _notesController.dispose();
    super.dispose();
  }

  Future<void> _submitBooking() async {
    if (!_formKey.currentState!.validate() || _selectedService == null) return;

    setState(() => _isSubmitting = true);
    try {
      final position = await _locationService.getCurrentPosition();

      final request = ServiceRequestModel(
        id: '',
        userId: '',
        providerId: widget.provider.id,
        serviceType: _selectedService!,
        notes: _notesController.text.trim().isEmpty ? null : _notesController.text.trim(),
        status: ServiceRequestStatus.pending,
        latitude: position.latitude,
        longitude: position.longitude,
        address: _addressController.text.trim(),
        createdAt: DateTime.now(),
      );

      await _apiService.post(ApiConfig.serviceRequests, body: request.toCreateJson());

      if (!mounted) return;
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('Booking request sent!')),
      );
      Navigator.of(context).popUntil((route) => route.isFirst);
    } catch (e) {
      if (!mounted) return;
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text('Failed to book: ${e.toString()}')),
      );
    } finally {
      if (mounted) setState(() => _isSubmitting = false);
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text('Book ${widget.provider.name}')),
      body: SafeArea(
        child: SingleChildScrollView(
          padding: const EdgeInsets.all(16),
          child: Form(
            key: _formKey,
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                const Text('Select a service', style: TextStyle(fontWeight: FontWeight.bold)),
                const SizedBox(height: 8),
                Wrap(
                  spacing: 8,
                  children: widget.provider.services.map((service) {
                    final selected = service == _selectedService;
                    return ChoiceChip(
                      label: Text(service),
                      selected: selected,
                      onSelected: (_) => setState(() => _selectedService = service),
                    );
                  }).toList(),
                ),
                const SizedBox(height: 20),
                CustomTextField(
                  controller: _addressController,
                  label: 'Service address',
                  hint: 'House no, street, area',
                  maxLength: 200,
                  validator: (v) =>
                      (v == null || v.trim().isEmpty) ? 'Address is required' : null,
                ),
                const SizedBox(height: 16),
                CustomTextField(
                  controller: _notesController,
                  label: 'Notes (optional)',
                  hint: 'Describe the issue briefly',
                  maxLength: 300,
                ),
                const SizedBox(height: 28),
                CustomButton(
                  label: 'Confirm booking',
                  isLoading: _isSubmitting,
                  onPressed: _submitBooking,
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}
