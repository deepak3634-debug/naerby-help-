import 'package:flutter/material.dart';
import '../../models/provider_model.dart';
import '../../widgets/custom_button.dart';
import '../booking/booking_screen.dart';

class ProviderProfileScreen extends StatelessWidget {
  final ProviderModel provider;
  const ProviderProfileScreen({super.key, required this.provider});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text(provider.name)),
      body: SafeArea(
        child: SingleChildScrollView(
          padding: const EdgeInsets.all(16),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Center(
                child: CircleAvatar(
                  radius: 48,
                  backgroundImage:
                      provider.avatarUrl != null ? NetworkImage(provider.avatarUrl!) : null,
                  child: provider.avatarUrl == null
                      ? const Icon(Icons.person, size: 48)
                      : null,
                ),
              ),
              const SizedBox(height: 16),
              Center(
                child: Row(
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    Text(provider.name,
                        style: const TextStyle(fontSize: 22, fontWeight: FontWeight.bold)),
                    if (provider.isVerified) ...[
                      const SizedBox(width: 6),
                      const Icon(Icons.verified, color: Colors.blue),
                    ],
                  ],
                ),
              ),
              const SizedBox(height: 4),
              Center(
                child: Row(
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    const Icon(Icons.star, color: Colors.amber, size: 20),
                    const SizedBox(width: 4),
                    Text('${provider.rating.toStringAsFixed(1)} · ${provider.totalReviews} reviews'),
                  ],
                ),
              ),
              const SizedBox(height: 24),
              const Text('Services offered', style: TextStyle(fontWeight: FontWeight.bold, fontSize: 16)),
              const SizedBox(height: 8),
              Wrap(
                spacing: 8,
                runSpacing: 8,
                children: provider.services
                    .map((s) => Chip(label: Text(s)))
                    .toList(),
              ),
              const SizedBox(height: 24),
              Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  const Text('Rate', style: TextStyle(fontWeight: FontWeight.bold, fontSize: 16)),
                  Text('₹${provider.pricePerHour.toStringAsFixed(0)} / hour',
                      style: const TextStyle(fontSize: 16)),
                ],
              ),
              const SizedBox(height: 8),
              Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  const Text('Status', style: TextStyle(fontWeight: FontWeight.bold, fontSize: 16)),
                  Row(
                    children: [
                      Container(
                        width: 10,
                        height: 10,
                        decoration: BoxDecoration(
                          shape: BoxShape.circle,
                          color: provider.isOnline ? Colors.green : Colors.grey,
                        ),
                      ),
                      const SizedBox(width: 6),
                      Text(provider.isOnline ? 'Online' : 'Offline'),
                    ],
                  ),
                ],
              ),
              const SizedBox(height: 32),
              CustomButton(
                label: 'Book this provider',
                onPressed: () {
                  Navigator.of(context).push(
                    MaterialPageRoute(
                      builder: (_) => BookingScreen(provider: provider),
                    ),
                  );
                },
              ),
            ],
          ),
        ),
      ),
    );
  }
}
