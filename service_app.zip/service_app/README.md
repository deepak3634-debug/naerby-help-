# Service App (Flutter)

An on-demand service marketplace app: users find nearby service providers,
authenticate via phone + OTP, and place bookings tracked in realtime via
Socket.io.

## Structure

```
lib/
├── main.dart                      # App entry, MultiProvider + AuthGate routing
├── config/
│   └── api_config.dart            # Backend base URL, socket URL, endpoints
├── models/
│   ├── user_model.dart
│   ├── provider_model.dart
│   └── service_request_model.dart
├── services/
│   ├── api_service.dart           # http wrapper (auth headers, error handling)
│   ├── auth_service.dart          # JWT + OTP flow, secure token storage
│   ├── socket_service.dart        # Socket.io client wrapper
│   └── location_service.dart      # geolocator wrapper
├── providers/                     # ChangeNotifier state management
│   ├── auth_provider.dart
│   └── nearby_provider.dart
├── screens/
│   ├── auth/
│   │   ├── login_screen.dart
│   │   └── otp_screen.dart
│   ├── home/
│   │   └── home_screen.dart
│   ├── provider_profile/
│   │   └── provider_profile_screen.dart
│   └── booking/
│       └── booking_screen.dart
└── widgets/
    ├── custom_button.dart
    ├── custom_text_field.dart
    ├── provider_card.dart
    └── loading_indicator.dart
```

## Getting started

This repo currently contains only the `lib/` source, `pubspec.yaml`, and
`analysis_options.yaml` — the Flutter SDK wasn't available in the sandbox
that generated this project, so the platform folders (`android/`, `ios/`,
`web/`, etc.) haven't been scaffolded yet. Generate them locally:

```bash
# 1. Unzip this project into an empty folder, then cd into it
cd service_app

# 2. Let Flutter generate platform folders (android/ios/web/etc.)
#    without touching the existing pubspec.yaml or lib/
flutter create . --project-name service_app --org com.yourcompany

# 3. Install dependencies
flutter pub get

# 4. Run it
flutter run
```

## Before running

1. **Backend URL** — edit `lib/config/api_config.dart` and set
   `Environment.current` / the URLs to point at your backend.
   `10.0.2.2` is the special alias for `localhost` from the Android emulator;
   use your machine's LAN IP for a physical device.
2. **Permissions** — after `flutter create .`, add location permissions:
   - **Android** (`android/app/src/main/AndroidManifest.xml`):
     ```xml
     <uses-permission android:name="android.permission.ACCESS_FINE_LOCATION"/>
     <uses-permission android:name="android.permission.ACCESS_COARSE_LOCATION"/>
     <uses-permission android:name="android.permission.INTERNET"/>
     ```
   - **iOS** (`ios/Runner/Info.plist`):
     ```xml
     <key>NSLocationWhenInUseUsageDescription</key>
     <string>We need your location to find nearby service providers.</string>
     ```
3. **Backend contract** — the app expects these REST endpoints (adjust
   `api_config.dart` / models to match your actual backend):
   - `POST /auth/send-otp` `{ phone }`
   - `POST /auth/verify-otp` `{ phone, otp }` → `{ accessToken, refreshToken, user }`
   - `POST /auth/refresh` `{ refreshToken }` → `{ accessToken, refreshToken }`
   - `GET  /auth/me` (Bearer token) → user object
   - `GET  /providers/nearby?lat=&lng=&radiusKm=` → list of providers
   - `POST /service-requests` → create a booking
   - Socket.io events: `request:join`, `request:leave`,
     `request:status_update`, `provider:location`

## Notes

- State management uses `provider` (ChangeNotifier) — swap for Riverpod/Bloc
  if preferred, the service layer is UI-agnostic so it isn't tightly coupled.
- Tokens are stored with `flutter_secure_storage` (Keychain/EncryptedSharedPreferences).
- `SocketService` is a singleton; call `SocketService().connect()` once the
  user is authenticated (e.g. from `HomeScreen.initState` or right after OTP
  verification), and `joinRequestRoom(requestId)` on the booking-tracking screen.
